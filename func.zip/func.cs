using System;
using Fission.DotNetCore.Api;

public class FissionFunction
{
    public string Execute(FissionContext context){
		string respo = "initial";
	        try
            {
				context.Logger.WriteInfo("Staring..... ");
				respo=$" sample object by getting Enum of   CsvHelper nuget dll: { CsvHelper.Caches.NamedIndex.ToString()}";
            }
            catch(Exception ex)
            {
				context.Logger.WriteError(ex.Message);
                respo = ex.Message;
            }
		context.Logger.WriteInfo("Done!");
		return respo;
    }
}
