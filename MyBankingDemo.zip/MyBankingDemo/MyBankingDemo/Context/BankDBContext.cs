﻿using MyBankingDemo.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace MyBankingDemo.Context
{
    public class BankDBContext : DbContext , IBankDBContext
    {
        public BankDBContext():base("BankDBConstr")
        {}

        public DbSet<Customer> Customers { get; set; }
        public DbSet<Account> Accounts { get; set; }

       public DbSet<Transaction> Transaction { get; set; }

        

        public override int SaveChanges()
        {
           return base .SaveChanges();
        }
    }
}