﻿using MyBankingDemo.DIUnity;
using MyBankingDemo.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace MyBankingDemo
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            // Web API configuration and services

            //unity configuration and passig as DI resolver to API
            var containerConfiguration = new Unityconfigurations();
            var container=containerConfiguration.ConfigureContainer();
            config.DependencyResolver = new UnityResolver(container);


            config.Filters.Add(new LoggingFilter());
            // Web API routes
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );
        }
    }
}
