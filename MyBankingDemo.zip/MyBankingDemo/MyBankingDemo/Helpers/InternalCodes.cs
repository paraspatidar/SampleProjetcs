﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyBankingDemo.Helpers
{
    public static class InternalCodes
    {
        public sealed class AccountCodes
        {
            private AccountCodes()
            {

            }
            public const string NOT_ENOUGH_BALANCE = "NOT_ENOUGH_BALANCE";
            public const string BALANCE_DEDUCTED = "BALANCE_DEDUCTED";
            public const string ERROR_OCCURED = "ERROR_OCCURED";
            
        }

        public sealed class TransCodes
        {
            private TransCodes()
            {

            }
            public const string CREDIT = "CREDIT";
            public const string DEBIT = "DEBIT";
            public const string ERROR_OCCURED = "ERROR_OCCURED";

        }
    }
}