﻿using MyBankingDemo.Context;
using MyBankingDemo.Models;
using MyBankingDemo.Repository.RepoBase;
using MyBankingDemo.Repository.RepoUnitWrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MyBankingDemo.Controllers
{
    public class ValuesController : ApiController
    {
        // GET api/values
        IRepoWrapper _repository = null;
        public ValuesController(IRepoWrapper repo)
        {
            this._repository = repo;
        }
        public Customer Get()
        {
            // return new string[] { "value1", "value2" };
            Customer cust = new Customer()
            {
                NameFirst = "aaass",
                NameLast = "1ws" + DateTime.Now.ToString()
            };

           _repository.CustomerRepository.CreateCustomer(cust);

            return cust;
        }

        // GET api/values/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        public void Post([FromBody]string value)
        {
        }

        // PUT api/values/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
        }
    }
}
