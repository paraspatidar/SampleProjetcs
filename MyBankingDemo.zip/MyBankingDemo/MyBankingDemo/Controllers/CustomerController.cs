﻿using MyBankingDemo.Models;
using MyBankingDemo.Repository.RepoUnitWrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MyBankingDemo.Controllers
{
    public class CustomerController : ApiController
    {
        // GET: api/Customer

        IRepoWrapper _repository = null;
        public CustomerController(IRepoWrapper repository)
        {
            _repository = repository;
        }
        public IEnumerable<Customer> Get()
        {
            return _repository.CustomerRepository.GetCustomers();
        }

        // GET: api/Customer/5
        public Customer Get(int id)
        {
            return _repository.CustomerRepository.GetCustomers().Where(x=>x.CustID==id).FirstOrDefault();
        }

        // POST: api/Customer
        public Customer Post([FromBody]Customer customer)
        {
          return  _repository.CustomerRepository.CreateCustomer(customer);
        }

        // PUT: api/Customer/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Customer/5
        public void Delete(int id)
        {
        }
    }
}
