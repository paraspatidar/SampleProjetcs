﻿using MyBankingDemo.Repository.RepoUnitWrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MyBankingDemo.Controllers
{
    
    public class AccountController : ApiController
    {
        // GET: api/Account

        IRepoWrapper _repository = null;
        public AccountController(IRepoWrapper repository)
        {
            _repository = repository;
        }

        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: api/Account/5
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Account
        public void Post([FromBody]string value)
        {
        }

        [Route("api/Account/AddFund/{acctid}")]
        [HttpPost]
        public IHttpActionResult AddFund([FromUri] int acctid , [FromBody]decimal? amount)
        {
         var balance=   _repository.AccountRepository.AddFundToAccount(acctid,amount.Value);
            return Ok(balance);
        }

        // PUT: api/Account/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Account/5
        public void Delete(int id)
        {
        }
    }
}
