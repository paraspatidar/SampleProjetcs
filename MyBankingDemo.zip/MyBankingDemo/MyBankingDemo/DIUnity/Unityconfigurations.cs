﻿using MyBankingDemo.Context;
using MyBankingDemo.Repository;
using MyBankingDemo.Repository.RepoBase;
using MyBankingDemo.Repository.RepoUnitWrapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Unity;
using Unity.Lifetime;

namespace MyBankingDemo.DIUnity
{
    public class Unityconfigurations
    {
        IUnityContainer container = null;  
        public IUnityContainer ConfigureContainer()
        {
            container = new UnityContainer();

            container.RegisterType<IBankDBContext, BankDBContext>(new HierarchicalLifetimeManager());

            container.RegisterType<ICustomerRepository, CustomerRepository>(new HierarchicalLifetimeManager());
            container.RegisterType<IAccountRepository, AccountRepository>(new HierarchicalLifetimeManager());
            container.RegisterType<ITransactionRepository, TransactionRepository>(new HierarchicalLifetimeManager());

            container.RegisterType<IRepoWrapper, RepoWrapper>(new HierarchicalLifetimeManager());
            
            return container;
        }
    }
}