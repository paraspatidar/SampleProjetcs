﻿using MyBankingDemo.Repository.RepoBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MyBankingDemo.Models;
using MyBankingDemo.Helpers;
using MyBankingDemo.Context;

namespace MyBankingDemo.Repository
{
    public class AccountRepository : BankBaseRepo, IAccountRepository
    {
        public AccountRepository(IBankDBContext dbcontext) : base(dbcontext)
        {
        }

        public decimal AddFundToAccount(int accId, decimal amountToDeposit)
        {
            var account = this._dbcontext.Accounts.Where(x => x.AccId == accId).SingleOrDefault();
            Transaction transaction = new Transaction()
            {
                AccId = account.AccId,
                PreviousBalance = account.CurruntBalance,
                CurruntBalance = account.CurruntBalance + amountToDeposit,
                TranType = InternalCodes.TransCodes.CREDIT
            };

            account.CurruntBalance = transaction.CurruntBalance;

            this._dbcontext.Transaction.Add(transaction);
            this._dbcontext.SaveChanges();
            return account.CurruntBalance;
        }

        public bool CreateAccount(Account account)
        {
            throw new NotImplementedException();
        }

        public decimal GetAccountBalance(int accId)
        {
            throw new NotImplementedException();
        }

        public string TranferFund(int accId,string AccountNumber, decimal amountToWidhraw)
        {
            throw new NotImplementedException();
        }

        public decimal WidhawAmount(int accId,decimal amountToWidhraw)
        {
            throw new NotImplementedException();
        }
    }
}