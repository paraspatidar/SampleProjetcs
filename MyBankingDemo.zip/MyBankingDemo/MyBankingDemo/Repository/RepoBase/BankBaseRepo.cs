﻿using MyBankingDemo.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyBankingDemo.Repository.RepoBase
{
    public class BankBaseRepo
    {
       protected IBankDBContext _dbcontext = null;

        public BankBaseRepo(IBankDBContext dbcontext)
        {
            _dbcontext = dbcontext;
        }
    }
}