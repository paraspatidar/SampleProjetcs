﻿using MyBankingDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyBankingDemo.Repository.RepoBase
{
  public  interface IAccountRepository
    {
        bool CreateAccount(Account account);
        decimal GetAccountBalance(int accId);

        //return the updated amount
        decimal AddFundToAccount(int accId, decimal amountToDeposit);

        //return the updated amount
        decimal WidhawAmount(int accId, decimal amountToWidhraw);

        //omiting other things like IFSC , MemberADded ind of logic for simplicity
        string  TranferFund(int accId, string ReceiverAccountNumber , decimal amountToWidhraw);
    }
}
