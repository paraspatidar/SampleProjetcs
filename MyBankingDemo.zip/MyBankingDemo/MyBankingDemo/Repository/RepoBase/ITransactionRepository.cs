﻿using MyBankingDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyBankingDemo.Repository.RepoBase
{
   public interface ITransactionRepository
    {
        void AddTransaction(int accid, decimal amount, string tranType);
        Transaction GetTransaction(int tid);

    }
}
