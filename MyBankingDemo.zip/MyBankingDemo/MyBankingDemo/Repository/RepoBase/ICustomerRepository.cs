﻿using MyBankingDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyBankingDemo.Repository.RepoBase
{
   public interface ICustomerRepository
    {
        Customer CreateCustomer(Customer customer);

        IEnumerable<Customer> GetCustomers();

        //return the specific account detail
        Account GetAccountDetails(int accId);

        //return the account associated with customer
        List<Account> GetAllAccount(int custId);

        //return the updated amount
        bool RemoveAccount(decimal amountToWidhraw);

     
    }
}
