﻿using MyBankingDemo.Repository.RepoBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyBankingDemo.Repository.RepoUnitWrapper
{
    public class RepoWrapper : IRepoWrapper
    {
        #region Private member variables...

        private ICustomerRepository _customerrepository;
        // private Historical_TRA_RecordsRepository historical_tra_recordsRepository;
        private IAccountRepository _accountrepository;
        private ITransactionRepository _transactionrepository;

        public RepoWrapper(ICustomerRepository customerrepository,IAccountRepository accountrepository, ITransactionRepository transactionrepository)
        {
            this._customerrepository = customerrepository;
            this._accountrepository = accountrepository;
            this._transactionrepository = transactionrepository;
        }

        public ICustomerRepository CustomerRepository
        {
            get
            {
                return this._customerrepository;
            }

            
        }

        public IAccountRepository AccountRepository
        {
            get
            {
                return this._accountrepository;
            }

            
        }

        public ITransactionRepository TransactionRepository
        {
            get
            {
                return this._transactionrepository;
            }

           
        }

        #endregion
    }
}