﻿using MyBankingDemo.Repository.RepoBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyBankingDemo.Repository.RepoUnitWrapper
{
   public interface IRepoWrapper
    {
        ICustomerRepository CustomerRepository { get;  }
        IAccountRepository AccountRepository { get;  }
        ITransactionRepository TransactionRepository { get; }
    }
}
