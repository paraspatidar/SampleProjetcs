﻿using MyBankingDemo.Repository.RepoBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MyBankingDemo.Models;
using MyBankingDemo.Context;

namespace MyBankingDemo.Repository
{
    public class CustomerRepository : BankBaseRepo, ICustomerRepository
    {
        public CustomerRepository(IBankDBContext dbcontext) : base(dbcontext)
        {
        }

        public Customer  CreateCustomer(Customer customer)
        {

            this._dbcontext.Customers.Add(customer);
            // ((BankDBContext)_dbcontext).SaveChangesAsync();
            this._dbcontext.SaveChanges();

            return customer;
        }


        public IEnumerable<Customer> GetCustomers()
        {

            return this._dbcontext.Customers;
            // ((BankDBContext)_dbcontext).SaveChangesAsync();
            

            
        }
        public Account GetAccountDetails(int accId)
        {
            throw new NotImplementedException();
        }

        public List<Account> GetAllAccount(int custId)
        {
            throw new NotImplementedException();
        }

        public bool RemoveAccount(decimal amountToWidhraw)
        {
            throw new NotImplementedException();
        }
    }
}