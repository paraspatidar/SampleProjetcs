﻿using MyBankingDemo.Repository.RepoBase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MyBankingDemo.Models;
using MyBankingDemo.Context;

namespace MyBankingDemo.Repository
{
    public class TransactionRepository :BankBaseRepo, ITransactionRepository
    {
        public TransactionRepository(IBankDBContext dbcontext) : base(dbcontext)
        {
        }
        public void AddTransaction(int accid, decimal amount, string tranType)
        {
            throw new NotImplementedException();
        }

        public Transaction GetTransaction(int tid)
        {
            return this._dbcontext.Transaction.Where(x => x.TransId == tid).SingleOrDefault();
        }
    }
}