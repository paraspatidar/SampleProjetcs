﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace MyBankingDemo.Filters
{
    public class LoggingFilter : ActionFilterAttribute
    {
        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            var requestURI = actionContext.Request.RequestUri.AbsoluteUri;
            Log(requestURI);
        }

        private void Log(string requestURI)
        {
            //throw new NotImplementedException();
        }
    }
}