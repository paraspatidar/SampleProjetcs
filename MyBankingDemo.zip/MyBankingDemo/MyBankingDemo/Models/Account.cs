﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace MyBankingDemo.Models
{
    public class Account
    {
        [Key]
        public int AccId { get; set; }
        public decimal CurruntBalance { get; set; }

        public int CustID { get; set; }
        [ForeignKey("CustID")]
        public virtual Customer Customer { get; set; }

    }
}