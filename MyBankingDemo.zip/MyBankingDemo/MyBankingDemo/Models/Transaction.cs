﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace MyBankingDemo.Models
{
    public class Transaction
    {
        [Key]
        public int TransId { get; set; }
        public decimal CurruntBalance { get; set; }
        public decimal PreviousBalance { get; set; }

        public string TranType { get; set; }
        public int AccId { get; set; }
        [ForeignKey("AccId")]
        public virtual Account Account { get; set; }
    }
}