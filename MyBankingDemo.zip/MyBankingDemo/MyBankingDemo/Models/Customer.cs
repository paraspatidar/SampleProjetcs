﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MyBankingDemo.Models
{
    public class Customer
    {
        [Key]
        public int CustID { get; set; }
        public string NameFirst { get; set; }
        public string NameLast { get; set; }

        public virtual List<Account> Accounts { get; set; }

    }
}